const express=require("express");
const router=express.Router();
const connection=require('../db/dbconnect.js');


router.get("/employees",(req,resp)=>{
    connection.query("select * from employee",(err,data)=>{
        if(err){
            resp.status(500).send("data not found"+JSON.stringify(err))
        }else{
            resp.send(data)
        }
    })
})
    
router.post("/employee",(req,resp)=>{

    var empid=req.body.empid;
    var name=req.body.name;
    var sal=req.body.sal;
    connection.query("insert into employee values(?,?,?)",[empid,name,sal],(err,result)=>{
        console.log(result);
        if(err){
            resp.status(500).send("data not inserted"+JSON.stringify(err))
        }else{
            if(result.affectedRows>0){
                resp.send("success")
            }else{
                resp.send("failed to insert data ")
            }
        }
    })
})
    router.delete("/employee/:empid",(req,resp)=>{
        connection.query("delete from employee where empid=?",[req.params.empid],(err,result)=>{
            console.log(result);
            if(err){
                resp.status(500).send("not deleted"+JSON.stringify(err))
            }else{
                if(result.affectedRows>0){
                    resp.send("deleted successfully")
                }else{
                    resp.send("not deleted")
                }
            }
        })
    })

     router.get("/employee/:empid",(req,resp)=>{
        connection.query("select * from employee where empid=?",[req.params.empid],(err,data)=>{
            if(err){
                resp.status(500).send("invalid id"+JSON.stringify(err))
            }else{
                resp.send(data[0])
            }
        })
     })
//   router.post("/employees",(req,resp)=>{
//     var empid=req.body.empid;
//     var name=req.body.name;
//     var sal=req.body.sal;
//     connection.query("insert into employee values(?,?,?)",[empid,name,sal],(err,result)=>{
//         console.log(result);
//         if (err){
//             resp.status(500).send("data not inserted")
//         } else{
//              if(result.affectedRows>0){
//                 resp.send("success")
//              }else {
//                 resp.send("unsuccessfull")
//              }
//         }
//     })
// //   }) 
//     router.delete("/employees/:empid",(req,resp)=>{
//         connection.query("delete from employee where empid=?",[req.params.empid],(err,result)=>{
//             console.log(result);
//             if(err){
//                 resp.status(500).send("not deleted"+JSON.stringify(err))
//             }else{
//                 if(result.affectedRows> 0){
//                     resp.send("deleted successfully")
//                 }else{
//                 resp.status(500).send("not deleted")
//                 }
//             }
//         })
//     })
//     router.put("/employees/update/:empid",(req,resp)=>{
//         var empid=req.body.empid;
//         var name=req.body.name;
//         var sal=req.body.sal;

//         connection.query("update employee set name=?,sal=? where empid=?",[name,sal,empid],(err,result)=>{
//             console.log(result);
//             if(err){
//                 resp.status(500).send("not updated")
//             }else {
//                 if(result.affectedRows>0){
//                     resp.send("updated successfully")
//                 }else{
//                     resp.status(500).send("updation unsuccessfull")
//                 }
//             }
//         })
//     })

// router.get("/employees/employee/:empid",(req,resp)=>{
//     connection.query("select * from emp where empid=?",[req.params.empid],(err,data)=>{
//         if(err){
//             resp.status(500).send("data not found"+JSON.stringify(err))
//         }else{
//             resp.send(data[0]);
//         }
//     })
// })
// router.post("/employee/employee/:eid",(req,resp)=>{
//   var empid=req.body.empid;
//   var ename=req.body.ename;
//   var sal=req.body.sal
//   connection.query("insert into emp values(?,?,?)",[empid,ename,sal],(err,result)=>{
//     console.log(result);
//     if(err){
//         resp.status(500).send("data not inserted")
//     }
//     else{
//         if(result.affectedRows> 0)
//            resp.send("{'msg':'inserted successfully'}")
//         else
//         resp.send("{'msg':'not inserted '}")
//     }
//   })
// })

// router.put("/employee/employee/:eid",(req,resp)=>{
//     var empid=req.body.empid;
//     var ename=req.body.ename;
//     var sal=req.body.sal
//     connection.query("update employee set ename=?,sal=? where empid=?",[ename,sal,empid],(err,result)=>{
//       console.log(result);
//       if(err){
//           resp.status(500).send("data not updated")
//       }
//       else{
//         if(result.affectedRows> 0)
//         resp.send("{'msg':'update successfully'}")
//      else
//      resp.send("{'msg':'not updated '}")
//       }
//     })
//   })

//   router.delete("/employee/employee/:eid",(req,resp)=>{
//     connection.query("delete from employee where empid=?",[req.params.empid],(err,result)=>{
//       console.log(result);
//       if(err){
//           resp.status(500).send("data not deleted")
//       }
//       else{
//         if(result.affectedRows> 0)
//         resp.send("{'msg':'deleted successfully'}")
//      else
//      resp.status(500).send("{'msg':'not deleted '}")
//       }
//     })
//   })


module.exports=router;