var mysql=require("mysql");

const mysqlconnection=mysql.createConnection({
    "host":"127.0.0.1",
    "user":"root",
    "password":"mohan123",
    "port":3306,
    "database":"dacmarch23"

})
mysqlconnection.connect((err)=>{
    if(err){
        console.log("error occured"+JSON.stringify(err))
    }else{
        console.log("connection successfull")
    }
})
    module.exports=mysqlconnection;







// var mysql=require("mysql");

// const mysqlconnection=mysql.createConnection({
//     "host":"127.0.0.1",
//     "user":"root",
//     "password":"mohan123",
//     "port":3306,
//     "database":"dacmarch23"
// })
// mysqlconnection.connect((err)=>{
//     if(err){
//         console.log("error occured"+JSON.stringify(err));
//     }
//     else{
//         console.log("connection done")
//     }

// })
// module.exports=mysqlconnection;

// /*
// var mysql=require("mysql");
// const mysqlcoonection=mysql.create({
//     "host":"127.0.0.1"
//     "user":"root"
//     "password":"mohan123"
//     "port":3306,
//     "databases":"dacmarch23"
// })
// mysqlconnection.connect((err)=>{
//    coonection.query("select * from employee",(err,resp)=>{
//     if(err){
//         resp.status(500).send("data not found"+JSON.stringyfy(err))
//     }
//    }) 
// })
